# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 13:47:55 2018

@author: haider.raheem-ug
"""

class stock:
    
    def __init__(self, name, count, price, city ):
        self.__name = name
        self.__count= count
        self.__price = price
        self.__city = city
    
    def getname(self):
        return self.__name
    
    def getcount(self):
        return self.__count
    
    def  getprice(self):
        return self.__price
    
    def getcity(self):
        return self.__city
    
    def setcount(self, count):
        self.__count= count
     
    def  __repr__ (self):
        return "Name: \t" + self.__name + "\n" + "Count: \t" + self.__count + "\n" + "Price: \t" + self.__price + "\n" + "City: \t"+self.__city 
        
    
    
    