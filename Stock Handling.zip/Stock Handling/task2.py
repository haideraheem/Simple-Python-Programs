# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 13:47:54 2018

@author: haider.raheem-ug
"""

from Stock import stock

def getByStockQuantity(l, x):
    newl = []
    for i in l:
        if int(i.getcount()) > x:
            newl.append(i)
    return newl

def getByPrice(l, x):
        newl = []
        for i in l :
            if float(i.getprice()) <= x:
                newl.append(i)
        return newl 

filehandle = open('input.txt', 'r')
stlist = []
for j in filehandle:
    nl = j.strip().split(',')    
    c = stock(nl[0], nl[1], nl[2], nl[3])
    stlist.append(c)

y =  getByStockQuantity(stlist, 5)
z =  getByPrice(y, 2)   

for k in z:
    print(k)
    print("  ")
filehandle.close()       
        
    
