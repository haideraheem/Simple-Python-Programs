# -*- coding: utf-8 -*-
"""
Created on Thu Dec  6 13:58:59 2018

@author: haider.raheem-ug
"""
from Question import Question

class MultipleChoiceQuestion(Question):
    
    def __init__(self, question, answer, score, choice):
        Question.__init__(self, question, answer, score)
        self.choice = choice 
    def getchoice(self):
        return self.choice
    def displayQuestion(self):
        print(self.getQuestion())
        for j in self.getchoice:
            print(j)
    def __str__(self):
       z= ""
       for k in self.getChoices():
           z =z+k+"\n"
       return Question.__str__(self)+"\n"+z