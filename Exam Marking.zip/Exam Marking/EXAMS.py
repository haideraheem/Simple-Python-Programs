# -*- coding: utf-8 -*-
"""
Created on Thu Dec  6 14:40:00 2018

@author: haider.raheem-ug
"""

from Question import Question

from MCQ import MultipleChoiceQuestion

def initializeQuestions(fh, l):
       filehandle =open(fh, 'r') 
       for i in filehandle:
           newl =[]
           i = i.split(';')
           if i[0] == 'M':
               newl = MultipleChoiceQuestion(i[1], i[2], int(i[3]), i[4].split(","))
               l.append(newl)
           elif i[0] == "R":
               newl = Question(i[1], i[2], int(i[3]))
               l.append(newl)    
       return l
       
def gradeExam(l) :
    total = 0
    print("********Grading Exam*********")
    for k in l:
        if k.isCorrectAnswer():
            total += k.getScore()
        else:
            print("Incorrect Answer")
            print(k)
    print("*********END OF GRADING*********")
    print("Your score is: "+ str(total))
    
fh = "questions.txt"

l = []

nlist = initializeQuestions(fh, l)

for j in nlist:
    j.displayQuestion()
    ans = input("Enter your answer: ")
    j.answerQuestion(ans)
    
gradeExam(nlist)    