# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 14:03:56 2018

@author: haider.raheem-ug
"""

from lab04_module import pluralize_words 

file = open('words.txt', 'r')
output = open('plurals.txt', 'w' )
for i in file:
    y = pluralize_words(i[:-1])
    output.write(y + "\n")
file.close()
output.close()