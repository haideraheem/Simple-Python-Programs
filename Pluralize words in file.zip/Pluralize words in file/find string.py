# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 14:03:57 2018

@author: haider.raheem-ug
"""
 
import lab04_module

s = input("enter first string: ")
s2 = input("enter second string: ")
   
a = lab04_module.findstring(s,s2)

print("'"+s2+"'", "appears in","'"+s+"'", a, "times")