# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 14:14:55 2018

@author: haider.raheem-ug
"""

def pluralize_words(s):
    x =s[-1]
    if x == "o":
        return s+"es"
    elif x == "y":
        y = s[0:-1]
        return y+"ies"
    else:
        return s+"s"
    
def findstring(s,s2):
    if len(s2) >len(s):
        return 0
    y = s.find(s2)
    if (y == -1):
        return 0
    else:
        return 1 + findstring(s[y+1:], s2)
    
